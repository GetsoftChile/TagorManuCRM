﻿namespace BotCasa.Classes
{
    public class IotMessage
    {
        public string id { get; set; }
        public string lightName { get; set; }
        public string lightStatus { get; set; }
    }
}